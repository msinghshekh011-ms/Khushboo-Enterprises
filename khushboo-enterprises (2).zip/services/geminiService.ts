import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize the client
const ai = new GoogleGenAI({ apiKey });

const SYSTEM_INSTRUCTION = `
You are the virtual assistant for "Khushboo Enterprises", a premier construction contractor firm. 
Your goal is to assist potential clients by providing information about the contractor, workers, past works, and methodology.

Key Information about Khushboo Enterprises:
- **Lead Contractor**: Mr. Ghanshyam Singh (Civil Engineer, 20+ years experience). Known for precision and honesty.
- **Team**: A dedicated team of 50+ skilled workers including master masons, certified electricians, carpenters, and safety officers.
- **Methodology (Way of Working)**: 
  1. Initial Consultation & Site Visit.
  2. Detailed Estimation & Transparency.
  3. Material Procurement (Only ISO certified brands).
  4. Execution with Daily Updates.
  5. Final Quality Check & Handover.
- **Specialties**: Residential Villas, Commercial Complexes, Renovation, and Structural Strengthening.
- **Values**: Safety First, On-time Delivery, No Hidden Costs.

When answering:
- Be professional, polite, and reassuring.
- Highlight the expertise of the workers and the contractor.
- If asked about prices, give a range but emphasize that a site visit is needed for an accurate quote.
- Use bullet points for clarity when listing services or steps.
`;

export const sendMessageToGemini = async (message: string, history: { role: string; parts: { text: string }[] }[]): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
      history: history,
    });

    const result = await chat.sendMessage({
      message: message,
    });

    return result.text;
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    throw new Error("I'm having trouble connecting to the server right now. Please try again later.");
  }
};