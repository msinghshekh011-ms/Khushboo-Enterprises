export interface WorkerProfile {
  id: number;
  name: string;
  role: string;
  experience: string;
  specialty: string;
  image: string;
}

export interface Project {
  id: number;
  title: string;
  category: string;
  description: string;
  completionDate: string;
  image: string;
}

export interface Service {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}