import React from 'react';
import { ClipboardCheck, BrickWall, Ruler, CheckCircle2 } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: "Consultation & Estimate",
    description: "We visit your site, understand your vision, and provide a detailed, transparent cost estimation with no hidden charges.",
    icon: <ClipboardCheck className="h-8 w-8 text-white" />
  },
  {
    id: 2,
    title: "Design & Planning",
    description: "Our engineers create structural drawings and 3D elevations. We plan material procurement to ensure zero delays.",
    icon: <Ruler className="h-8 w-8 text-white" />
  },
  {
    id: 3,
    title: "Execution & Construction",
    description: "Our skilled masons and workers take over. We use only premium cement, steel, and fixtures. Weekly progress reports provided.",
    icon: <BrickWall className="h-8 w-8 text-white" />
  },
  {
    id: 4,
    title: "Quality Check & Handover",
    description: "A comprehensive 50-point quality check is conducted before we hand over the keys to your dream space.",
    icon: <CheckCircle2 className="h-8 w-8 text-white" />
  }
];

const Process: React.FC = () => {
  return (
    <section id="process" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-base text-orange-600 font-semibold tracking-wide uppercase">Methodology</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Our Way of Working
          </p>
          <p className="mt-4 max-w-2xl text-xl text-slate-500 mx-auto">
            Transparency and precision are the cornerstones of Khushboo Enterprises. Here is how we turn your idea into a structure.
          </p>
        </div>

        <div className="relative">
            {/* Connecting line for large screens */}
            <div className="hidden lg:block absolute top-12 left-0 w-full h-0.5 bg-slate-200 -z-10" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step) => (
                <div key={step.id} className="bg-white p-6 rounded-xl shadow-md border border-slate-100 relative group hover:-translate-y-1 transition-transform duration-300">
                    <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center mb-6 shadow-lg group-hover:bg-orange-600 transition-colors duration-300 mx-auto lg:mx-0">
                        {step.icon}
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-3 text-center lg:text-left">{step.title}</h3>
                    <p className="text-slate-600 leading-relaxed text-center lg:text-left">
                        {step.description}
                    </p>
                    <div className="absolute top-6 right-6 text-6xl font-black text-slate-100 -z-10 group-hover:text-orange-50 transition-colors">
                        0{step.id}
                    </div>
                </div>
            ))}
            </div>
        </div>
      </div>
    </section>
  );
};

export default Process;