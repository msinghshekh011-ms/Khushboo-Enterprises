import React from 'react';
import { Project } from '../types';

const projects: Project[] = [
  {
    id: 1,
    title: "Harsh Mountain",
    category: "Tourist Area",
    description: "Wooden railing, watch towers, parking area, sun set view point.",
    completionDate: "Dec 2023",
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpuyh8oQpXJwY0KGPIXbJ6LC950Ep2f-pmOw&s"
  },
  {
    id: 2,
    title: "Ecological Park and Bird Sanctruary",
    category: "Tourist Area",
    description: "Beautiful entrance, ponds for birds, etc.",
    completionDate: "Aug 2022",
    image: "https://content.jdmagicbox.com/comp/gurgaon/i7/011pxx11.xx11.120221123103.q2i7/catalogue/sultanpur-national-park-bird-sanctuary-sultanpur-gurgaon-gurgaon-tourist-attraction-t48dm4w3mj.jpg"
  },
  {
    id: 3,
    title: "City Center Mall Renovation",
    category: "Commercial",
    description: "Complete facade renovation and interior structural strengthening for a local shopping hub.",
    completionDate: "Feb 2024",
    image: "https://picsum.photos/600/400?random=22"
  },
  {
    id: 4,
    title: "Greenwood Office Park",
    category: "Commercial",
    description: "Eco-friendly office space construction using sustainable materials and solar integration.",
    completionDate: "Nov 2022",
    image: "https://picsum.photos/600/400?random=23"
  },
  {
    id: 5,
    title: "Smriti Van",
    category: "Forest area",
    description: "Asthetic entrance, instruction board, etc.",
    completionDate: "Mar 2023",
    image: "https://content.jdmagicbox.com/comp/sikar/h8/9999p1572.1572.200627202435.r7h8/catalogue/smriti-van-industrial-area-sikar-parks-PhzpiTtKBt.jpg"
  },
  {
    id: 6,
    title: "Modern Loft Conversion",
    category: "Renovation",
    description: "Converting an old warehouse into premium loft apartments.",
    completionDate: "Jan 2024",
    image: "https://picsum.photos/600/400?random=25"
  }
];

const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
            <div className="max-w-2xl">
                <h2 className="text-base text-orange-600 font-semibold tracking-wide uppercase">Portfolio</h2>
                <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
                    Our Past Works
                </p>
                <p className="mt-4 text-xl text-slate-500">
                    From cozy homes to towering complexes, our portfolio speaks for our versatility and quality.
                </p>
            </div>
            <div className="mt-4 md:mt-0">
                <button className="text-orange-600 font-medium hover:text-orange-700 flex items-center gap-1">
                    View All Projects &rarr;
                </button>
            </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div key={project.id} className="group relative bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer">
              <div className="relative h-64 w-full overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                    <div className="p-6">
                        <p className="text-orange-400 font-medium text-sm">{project.category}</p>
                        <h3 className="text-white text-xl font-bold">{project.title}</h3>
                    </div>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-orange-600 transition-colors">{project.title}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">
                        {project.completionDate}
                    </span>
                </div>
                <p className="text-slate-600 text-sm line-clamp-2">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;