import React from 'react';
import { HardHat, Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-slate-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Info */}
          <div>
            <div className="flex items-center gap-2 mb-6">
                <HardHat className="h-8 w-8 text-orange-500" />
                <span className="font-bold text-2xl">Khushboo Ent.</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Building trust since 2006. We are committed to providing top-notch construction services with integrity and skilled craftsmanship.
            </p>
            <div className="flex gap-4">
                <a href="#" className="text-slate-400 hover:text-white transition-colors"><Facebook className="h-5 w-5" /></a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors"><Instagram className="h-5 w-5" /></a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors"><Linkedin className="h-5 w-5" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Quick Links</h3>
            <ul className="space-y-3 text-sm text-slate-400">
                <li><a href="#home" className="hover:text-orange-500 transition-colors">Home</a></li>
                <li><a href="#team" className="hover:text-orange-500 transition-colors">Our Team</a></li>
                <li><a href="#process" className="hover:text-orange-500 transition-colors">Methodology</a></li>
                <li><a href="#portfolio" className="hover:text-orange-500 transition-colors">Portfolio</a></li>
                <li><a href="#ai-assistant" className="hover:text-orange-500 transition-colors">Ask AI</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Contact Us</h3>
            <ul className="space-y-4 text-sm text-slate-400">
                <li className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span>123, Construction Avenue,<br/>Sikar, Rajasthan, India</span>
                </li>
                <li className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-orange-500 flex-shrink-0" />
                    <span>+91 95291 56615</span>
                </li>
                <li className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-orange-500 flex-shrink-0" />
                    <span>contact@khushboo-ent.com</span>
                </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Get A Quote</h3>
            <p className="text-slate-400 text-sm mb-4">Leave your email and we'll send you a brochure.</p>
            <div className="flex">
                <input type="email" placeholder="Your email" className="bg-slate-800 border-none text-white px-4 py-2 rounded-l-md w-full focus:ring-1 focus:ring-orange-500 outline-none" />
                <button className="bg-orange-600 px-4 py-2 rounded-r-md hover:bg-orange-700 transition-colors">
                    <SendIcon className="h-4 w-4" />
                </button>
            </div>
          </div>

        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
            <p>&copy; {new Date().getFullYear()} Khushboo Enterprises. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

// Helper for newsletter icon since Lucide Send is used in AIChat, avoiding collision or just inline it
const SendIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
);

export default Footer;