import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Sparkles, AlertCircle } from 'lucide-react';
import { sendMessageToGemini } from '../services/geminiService';
import { ChatMessage } from '../types';

const AIChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Namaste! I am the AI assistant for Khushboo Enterprises. Ask me anything about our contractor Mr. Ghanshyam singh, our skilled workers, or how we can build your dream project." }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', text: inputValue };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Format history for Gemini API
      const history = messages.map(msg => ({
        role: msg.role === 'model' ? 'model' : 'user',
        parts: [{ text: msg.text }]
      }));

      const responseText = await sendMessageToGemini(userMessage.text, history);
      
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: "I apologize, but I'm having trouble connecting to the server. Please try again or contact us directly at +91-9876543210.",
        isError: true 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <section id="ai-assistant" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
          {/* Left Side: Info */}
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/20 text-indigo-300 text-sm font-medium mb-6">
                <Sparkles className="h-4 w-4" />
                <span>AI Powered Assistant</span>
            </div>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl mb-6">
              Have Questions about Construction?
            </h2>
            <p className="text-lg text-slate-400 mb-8">
              Whether you want to know about our cement quality, labor charges, or Mr. Ghanshyam singh's experience, our smart assistant is here 24/7 to help you.
            </p>
            <div className="space-y-4">
                <div className="flex gap-4">
                    <div className="bg-slate-800 p-3 rounded-lg h-fit">
                        <Bot className="h-6 w-6 text-orange-500" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold">Instant Answers</h4>
                        <p className="text-slate-400 text-sm">Get details about our past projects and worker expertise instantly.</p>
                    </div>
                </div>
                <div className="flex gap-4">
                    <div className="bg-slate-800 p-3 rounded-lg h-fit">
                        <User className="h-6 w-6 text-orange-500" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold">Know Your Team</h4>
                        <p className="text-slate-400 text-sm">Learn about the people who will be building your home.</p>
                    </div>
                </div>
            </div>
          </div>

          {/* Right Side: Chat Interface */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-700 h-[600px] flex flex-col">
            <div className="bg-slate-100 p-4 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="bg-orange-500 p-2 rounded-full">
                        <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-800">Khushboo Assistant</h3>
                        <p className="text-xs text-green-600 flex items-center gap-1">
                            <span className="w-2 h-2 bg-green-500 rounded-full"></span> Online
                        </p>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex items-start max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${msg.role === 'user' ? 'bg-slate-200 ml-2' : 'bg-orange-100 mr-2'}`}>
                      {msg.role === 'user' ? <User className="h-5 w-5 text-slate-600" /> : <Bot className="h-5 w-5 text-orange-600" />}
                    </div>
                    <div className={`p-3 rounded-2xl text-sm ${
                        msg.role === 'user' 
                        ? 'bg-slate-800 text-white rounded-tr-none' 
                        : msg.isError 
                            ? 'bg-red-50 text-red-800 border border-red-200 rounded-tl-none'
                            : 'bg-white text-slate-800 shadow-sm border border-slate-100 rounded-tl-none'
                    }`}>
                      {msg.text.split('\n').map((line, i) => (
                        <p key={i} className={i > 0 ? 'mt-1' : ''}>{line}</p>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                    <div className="flex items-center gap-2 bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
                        <Loader2 className="h-4 w-4 animate-spin text-orange-500" />
                        <span className="text-xs text-slate-500">Khushboo Enterprises is typing...</span>
                    </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 bg-white border-t border-slate-200">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about Mr. Ghanshyam Singh, our masons, or past work..."
                  className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-slate-700 placeholder-slate-400"
                  disabled={isLoading}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={isLoading || !inputValue.trim()}
                  className="bg-orange-600 text-white p-2 rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIChat;