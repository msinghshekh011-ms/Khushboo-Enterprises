import React from 'react';
import { WorkerProfile } from '../types';
import { User, Award, ShieldCheck, Users } from 'lucide-react';

const workers: WorkerProfile[] = [
  {
    id: 1,
    name: "Mr. Ghanshyam Singh",
    role: "Lead Contractor & Founder",
    experience: "20+ Years",
    specialty: "Civil Engineering & Project Management",
    image: "https://static.vecteezy.com/system/resources/thumbnails/046/035/310/small/business-man-silhouette-man-with-suit-standing-illustration-business-man-logo-vector.jpg"
  },
  {
    id: 2,
    name: "Ganpat",
    role: "Fabricator",
    experience: "20+ Years",
    specialty: "Custom Ironwork",
    image: "https://static.vecteezy.com/system/resources/thumbnails/046/035/310/small/business-man-silhouette-man-with-suit-standing-illustration-business-man-logo-vector.jpg"
  {
    id: 3,
    name: "Manoj Kumar",
    role: "Mason",
    experience: "15 Years",
    specialty: "Structural Masonry",
    image: "https://static.vecteezy.com/system/resources/thumbnails/046/035/310/small/business-man-silhouette-man-with-suit-standing-illustration-business-man-logo-vector.jpg"
  },
  {
    id: 4,
    name: "Girdhari",
    role: "Senior Carpenter",
    experience: "12 Years",
    specialty: "Custom Woodwork & Roofing",
    image: "https://static.vecteezy.com/system/resources/thumbnails/046/035/310/small/business-man-silhouette-man-with-suit-standing-illustration-business-man-logo-vector.jpg"
  },
  {
    id: 5,
    name: "Team Alpha",
    role: "General Workforce",
    experience: "Various",
    specialty: "Excavation & Finishing",
    image: "https://static.vecteezy.com/system/resources/thumbnails/046/035/310/small/business-man-silhouette-man-with-suit-standing-illustration-business-man-logo-vector.jpg"
  }
];

const Team: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-base text-orange-600 font-semibold tracking-wide uppercase">Our People</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Meet The Backbone of Khushboo Enterprises
          </p>
          <p className="mt-4 max-w-2xl text-xl text-slate-500 mx-auto">
            Our strength lies in our skilled workforce. We don't just hire workers; we cultivate craftsmen who take pride in their work.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {workers.map((worker) => (
            <div key={worker.id} className="bg-slate-50 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 border border-slate-100 group">
              <div className="h-64 overflow-hidden">
                <img 
                  src={worker.image} 
                  alt={worker.name} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-bold text-slate-900">{worker.name}</h3>
                <p className="text-orange-600 font-medium mb-2">{worker.role}</p>
                <div className="space-y-2 mt-4">
                  <div className="flex items-center text-sm text-slate-600">
                    <Award className="h-4 w-4 mr-2 text-slate-400" />
                    <span>Experience: {worker.experience}</span>
                  </div>
                  <div className="flex items-center text-sm text-slate-600">
                    <ShieldCheck className="h-4 w-4 mr-2 text-slate-400" />
                    <span>Focus: {worker.specialty}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-slate-900 rounded-2xl p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0">
            <h3 className="text-2xl font-bold flex items-center gap-3">
              <Users className="h-8 w-8 text-orange-500" />
              Why Our Team?
            </h3>
            <p className="mt-2 text-slate-300 max-w-xl">
              All our workers are background-checked, insured, and undergo regular safety training. We believe a happy team builds a happy home.
            </p>
          </div>
          <div className="flex gap-8 text-center">
            <div>
              <p className="text-3xl font-bold text-orange-500">50+</p>
              <p className="text-sm text-slate-400">Skilled Workers</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-orange-500">100%</p>
              <p className="text-sm text-slate-400">Safety Record</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;