import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div id="home" className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/1920/1080?grayscale&blur=2" 
          alt="Construction Site" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-slate-900/70"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight mb-6">
          Building Trust, <br />
          <span className="text-orange-500">Constructing Dreams</span>
        </h1>
        <p className="mt-4 text-xl text-slate-200 mb-8 max-w-3xl mx-auto">
          Khushboo Enterprises brings 25 years of engineering excellence. 
          Led by Mr. Ghanshyam Singh, we deliver precision, safety, and quality in every brick we lay.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="#portfolio" className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 md:py-4 md:text-lg transition-all">
            View Our Work
          </a>
          <a href="#ai-assistant" className="inline-flex items-center justify-center px-8 py-3 border-2 border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-slate-900 md:py-4 md:text-lg transition-all gap-2">
            Ask About Us <ArrowRight className="h-5 w-5" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Hero;